
clickatell_defaults = {
        'interface_version':'34',
        'dest_addr_ton':1,
        'dest_addr_npi':1,
}

